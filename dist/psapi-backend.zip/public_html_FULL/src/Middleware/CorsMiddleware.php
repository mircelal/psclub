<?php

declare(strict_types=1);

namespace App\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Slim\Psr7\Response;

final class CorsMiddleware implements MiddlewareInterface
{
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $origin = $_ENV['CORS_ORIGIN'] ?? '*';

        if ($request->getMethod() === 'OPTIONS') {
            $response = new Response(204);
            return $this->withCors($response, $origin);
        }

        $response = $handler->handle($request);

        return $this->withCors($response, $origin);
    }

    private function withCors(ResponseInterface $response, string $origin): ResponseInterface
    {
        $requestOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $allowed = $origin === '*' ? '*' : $origin;
        if ($allowed !== '*' && $requestOrigin !== '' && $requestOrigin === $origin) {
            $allowed = $requestOrigin;
        }

        return $response
            ->withHeader('Access-Control-Allow-Origin', $allowed)
            ->withHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Accept')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS')
            ->withHeader('Access-Control-Max-Age', '86400');
    }
}
